// Problem Statement: DFS
#include <iostream>
#include <vector>
#include <omp.h>
using namespace std;

class Graph {
    int V;
    vector<vector<int>> adj;

public:
    Graph(int V) {
        this->V = V;
        adj.resize(V);
    }

    void addEdge(int u, int v) {
        adj[u].push_back(v);
        adj[v].push_back(u); // undirected graph
    }

    void parallelDFSUtil(int v, vector<bool> &visited) {
        visited[v] = true;

        #pragma omp critical
        cout << v << " ";

        #pragma omp parallel for
        for (int i = 0; i < adj[v].size(); i++) {
            int neighbor = adj[v][i];

            if (!visited[neighbor]) {
                #pragma omp task
                parallelDFSUtil(neighbor, visited);
            }
        }
    }

    void parallelDFS(int start) {
        vector<bool> visited(V, false);

        #pragma omp parallel
        {
            #pragma omp single
            {
                parallelDFSUtil(start, visited);
            }
        }
    }
};

int main() {
    int V, E;
    cout << "Enter number of vertices: ";
    cin >> V;

    cout << "Enter number of edges: ";
    cin >> E;
    Graph g(V);
    cout << "Enter edges (u v):\n";
    for (int i = 0; i < E; i++) {
        int u, v;
        cin >> u >> v;
        g.addEdge(u, v);
    }
    int start;
    cout << "Enter starting vertex: ";
    cin >> start;
    cout << "DFS Traversal:\n";
    g.parallelDFS(start);
    return 0;
}
/*
✅ Compile Command (Linux / WSL / macOS)
g++ -fopenmp dfs.cpp -o dfs
▶️ Run Command
./dfs
✅ Windows (MinGW / MSYS2)
Compile:
g++ -fopenmp dfs.cpp -o dfs.exe
Run:
dfs.exe*/

/*
Enter number of vertices:
5
Enter number of edges:
4
Enter edges (u v):
0 1
0 2
1 3
1 4
Enter starting vertex:
0
DFS Traversal:
0 1 3 4 2  
*/
