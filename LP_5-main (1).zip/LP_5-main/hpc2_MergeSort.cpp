// Problem statement: Parallel merge sort
#include <iostream>
#include <vector>
#include <omp.h>
using namespace std;

void merge(vector<int> &arr, int left, int mid, int right) {
    vector<int> temp(right - left + 1);

    int i = left, j = mid + 1, k = 0;

    while (i <= mid && j <= right) {
        if (arr[i] <= arr[j])
            temp[k++] = arr[i++];
        else
            temp[k++] = arr[j++];
    }

    while (i <= mid) temp[k++] = arr[i++];
    while (j <= right) temp[k++] = arr[j++];

    for (int i = left, k = 0; i <= right; i++, k++)
        arr[i] = temp[k];
}

void parallelMergeSort(vector<int> &arr, int left, int right) {
    if (left < right) {
        int mid = (left + right) / 2;

        #pragma omp parallel sections
        {
            #pragma omp section
            parallelMergeSort(arr, left, mid);

            #pragma omp section
            parallelMergeSort(arr, mid + 1, right);
        }

        merge(arr, left, mid, right);
    }
}

int main() {
    int n;
    cout << "Enter number of elements: ";
    cin >> n;

    vector<int> arr(n);
    cout << "Enter elements:\n";
    for (int i = 0; i < n; i++) cin >> arr[i];

    parallelMergeSort(arr, 0, n - 1);

    cout << "\nSorted Array:\n";
    for (int x : arr) cout << x << " ";

    return 0;
}

/*
✅ Compile Command
Linux / WSL / macOS:
g++ -fopenmp mergesort.cpp -o mergesort
▶️ Run Command
./mergesort
✅ Windows (MinGW / MSYS2)
Compile:
g++ -fopenmp mergesort.cpp -o mergesort.exe
Run:
mergesort.exe  */


/* Enter number of elements:
5
Enter elements:
5 2 9 1 6

Sorted Array:
1 2 5 6 9 
 */
